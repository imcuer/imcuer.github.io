# 🌱 hugo-theme-dream

![GitHub Release](https://img.shields.io/github/v/release/g1eny0ung/hugo-theme-dream)
![GitHub License](https://img.shields.io/github/license/g1eny0ung/hugo-theme-dream)

> [!IMPORTANT]
> The latest version of Dream is v3.x.
>
> If you are using v2.x, please check the [v2 branch](https://github.com/g1eny0ung/hugo-theme-dream/tree/v2) and its [docs](https://hugo-theme-dream-docs-v2.netlify.app/).

- [Intro](#intro)
- [Documentation](#documentation)
- [Examples](#examples)
- [Publish your site](#publish-your-site)

## Intro

Dream is a [Hugo](https://gohugo.io/) theme. I build it for [my blog](https://g1en.site).

The main features are **Masonry Layout Posts** and **Flippable About Page**.

Dream also supports **light and dark mode** out of the box.

![Screenshot](https://github.com/g1eny0ung/hugo-theme-dream/blob/master/images/screenshot.png?raw=true)

For people who prefer a simple and clean interface,
Dream has a [**Zen mode**](https://hugo-theme-dream.g1en.site/zen-mode).
It is more concentrated on reading and writing.

<img src="https://github.com/g1eny0ung/hugo-theme-dream/blob/master/docs/public/images/zen-mode.png?raw=true" alt="Zen Mode" height="500" />

## Documentation

<https://hugo-theme-dream.g1en.site>

## Examples

- [My blog](https://g1en.site) and its [source code](https://github.com/g1eny0ung/blog)
- [A demo of Zen mode](https://g1en-site-zen-mode-preview.netlify.app/)

## Publish your site

See [Hosting & Deployment](https://gohugo.io/hosting-and-deployment/).

## License

🌱 Hugo Theme Dream is licensed under the MIT License.

Author: [g1eny0ung](https://github.com/g1eny0ung).
